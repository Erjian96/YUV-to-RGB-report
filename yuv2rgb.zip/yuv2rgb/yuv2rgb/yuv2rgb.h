int YUV2RGB (int x_dim, int y_dim, void *rgb, void *y_in, void *u_in, void *v_in);

void InitLookupTable();
