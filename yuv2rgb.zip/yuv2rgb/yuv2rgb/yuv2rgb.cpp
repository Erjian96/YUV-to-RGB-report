#include "stdlib.h"
#include "yuv2rgb.h"

static float YUVRGB1772[256];
static float YUVRGB034414[256], YUVRGB071414[256];
static float YUVRGB1402[256];

int YUV2RGB (int x_dim, int y_dim, void *rgb, void *y_in, void *u_in, void *v_in)
{	static int init_done = 0;
	long i, j, size;
	unsigned char *y, *y2;
	unsigned char *sub_u, *sub_v;
	unsigned char *rgbout;
	int *out1,*out2,*myout;
	// lookup table 
	if (init_done == 0)
	{
		InitLookupTable();
		init_done = 1;
	}
	// read in Y,U,V
	size = x_dim * y_dim;
	myout = (int *)malloc(size * 3 * sizeof(int));
	y = (unsigned char *)y_in;
	sub_u = (unsigned char *)u_in;
	sub_v = (unsigned char *)v_in;
	rgbout = (unsigned char *)rgb;
	// convert YUV to RGB
	out1 = myout;
	for (j = 0; j < y_dim/2; j ++)
	{		
		out2 = out1 + x_dim * 3;
		y2 = y + x_dim;
		for (i = 0; i < x_dim/2; i ++)
		{	//top left
			*out1 = (int)(*y + YUVRGB1772[*sub_u]);
			*(out1 + 1) = (int)(*y - YUVRGB034414[*sub_u] - YUVRGB071414[*sub_v]);
			*(out1 + 2)= (int)(  *y + YUVRGB1402[*sub_v]);
			//top right
			*(out1 + 3) = (int)(*(y+1) + YUVRGB1772[*sub_u]);
			*(out1 + 4) = (int)(*(y+1) - YUVRGB034414[*sub_u] - YUVRGB071414[*sub_v]);
			*(out1 + 5) = (int)(*(y+1) + YUVRGB1402[*sub_v]);
			//bottom left
			*out2 = (int)(*y2 + YUVRGB1772[*sub_u]);
			*(out2 + 1) = (int)(*y2 - YUVRGB034414[*sub_u] - YUVRGB071414[*sub_v]);	
			*(out2 + 2)= (int)(  *y2 + YUVRGB1402[*sub_v]);		
			//bottom right
			*(out2 + 3) = (int)(*(y2+1) + YUVRGB1772[*sub_u]);		
			*(out2 + 4) = (int)(*(y2+1) - YUVRGB034414[*sub_u] - YUVRGB071414[*sub_v]);
			*(out2 + 5) = (int)(*(y2+1) + YUVRGB1402[*sub_v]);
			sub_u ++;
			sub_v ++;
			y += 2;
			y2 += 2;
			out1 += 6;
			out2 += 6;
		}
		y += x_dim;
		out1 += 3 * x_dim;
	}
	for(i = 0; i < size * 3; i ++)
	{
		if(myout[i] > 255) myout[i] = 255;
		if(myout[i] < 0) myout[i] = 0;
		rgbout[i] = (unsigned char )myout[i];
	}
	if(myout)
		{
			free(myout);
		}
	return 0;
}
void InitLookupTable()
{
	int i;
	for (i = 0; i < 256; i++) YUVRGB1772[i] = (float)1.779 * (i - 128);
	for (i = 0; i < 256; i++) YUVRGB034414[i] = (float)0.3455 * (i - 128);
	for (i = 0; i < 256; i++) YUVRGB071414[i] = (float)0.7169 * (i - 128);
	for (i = 0; i < 256; i++) YUVRGB1402[i] = (float)1.4075 * (i - 128);

}
