#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "yuv2rgb.h"

#define u_int8_t	unsigned __int8
#define u_int		unsigned __int32
#define u_int32_t	unsigned __int32
#define FALSE		false
#define TRUE		true
/*
 * yuv2rgb
 * required arg1 should be the input RAW  YUV file
 * required arg2 should be the output RAW RGB file
 */ 
int main(int argc, char** argv)
{
	/* variables controlable from command line */
	u_int frameWidth = 352;			/* --width=<uint> */
	u_int frameHeight = 240;		/* --height=<uint> */
	bool flip = TRUE;				/* --flip */
	unsigned int i;
	/* internal variables */
	char* yuvFileName = NULL;
	char* rgbFileName = NULL;
	FILE* yuvFile = NULL;
	FILE* rgbFile = NULL;
	u_int8_t* rgbBuf = NULL;
	u_int8_t* yBuf = NULL;
	u_int8_t* uBuf = NULL;
	u_int8_t* vBuf = NULL;
	u_int32_t videoFramesWritten = 0;
	/* begin process command line */
	/* point to the specified file names */
	yuvFileName = argv[1];
	rgbFileName = argv[2];
	frameWidth = atoi(argv[3]);
	frameHeight = atoi(argv[4]);
	/* open the YUV file */
	yuvFile = fopen(yuvFileName, "rb");
	if (yuvFile == NULL)
	{
		printf("cannot find yuv file\n");
		exit(1);
	}
	else
	{
		printf("The input yuv file is %s\n", yuvFileName);
	}
	/* open the RAW file */
	rgbFile = fopen(rgbFileName, "wb");
	if (rgbFile == NULL)
	{
		printf("cannot find rgb file\n");
		exit(1);
	}
	else
	{
		printf("The output rgb file is %s\n", rgbFileName);
	}
	/* get the output buffers for a frame */
	rgbBuf = (u_int8_t*)malloc(frameWidth * frameHeight * 3);
	/* get the input buffers for a frame */
	yBuf = (u_int8_t*)malloc(frameWidth * frameHeight);
	uBuf = (u_int8_t*)malloc((frameWidth * frameHeight) / 4);
	vBuf = (u_int8_t*)malloc((frameWidth * frameHeight) / 4);
	if (rgbBuf == NULL || yBuf == NULL || uBuf == NULL || vBuf == NULL)
	{
		printf("no enought memory\n");
		exit(1);
	}
	while (fread(yBuf, 1, frameWidth * frameHeight, yuvFile) && fread(uBuf, 1, frameWidth * frameHeight /4, yuvFile)  
        && fread(vBuf, 1, frameWidth * frameHeight /4, yuvFile))  
    {  
		if(YUV2RGB(frameWidth, frameHeight, rgbBuf, yBuf, uBuf, vBuf))
		{
			printf("error");
			return 0;
		}
		//write rgbfile
		fwrite(rgbBuf, 1, frameWidth * frameHeight*3, rgbFile);
		//rate of progress
		printf("\r...%d", ++videoFramesWritten);
	}
		printf("\n%u %ux%u video frames written\n", 
		videoFramesWritten, frameWidth, frameHeight);
	/* cleanup */
		if(rgbBuf)
		{
			free(rgbBuf);
		}
		if(yBuf)
		{
			free(yBuf);
		}
		if(uBuf)
		{
			free(uBuf);
		}
		if(vBuf)
		{
			free(vBuf);
		}
		if(rgbFile)
		{
			fclose(rgbFile);
		}
	return(0);
}